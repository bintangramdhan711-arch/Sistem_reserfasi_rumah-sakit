<?php

// 1. Panggil koneksi database
include_once __DIR__ . "/../../php/config/koneksi.php";

// 2. Panggil file Helper yang berisi fungsi formatRupiah
require_once __DIR__ . "/../../php/interfaceandmodel/SistemHelper.php";

// 3. Gunakan fungsi formatRupiah dari namespace SistemHelper
use function SistemHelper\formatRupiah;

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Reservasi RS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #F4F6FA;
            margin: 0;
        }

        /* ── NAVBAR ── */
        .navbar-custom {
            background: linear-gradient(135deg, #185FA5 0%, #0C447C 100%);
            padding: 0;
            box-shadow: 0 1px 4px rgba(0,0,0,0.15);
        }
        .navbar-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 28px;
        }
        .nav-brand {
            color: #fff;
            font-size: 17px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }
        .nav-brand .brand-icon {
            width: 34px;
            height: 34px;
            background: rgba(255,255,255,0.15);
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
        }
        .nav-meta {
            color: rgba(255,255,255,0.7);
            font-size: 13px;
        }

        /* ── MAIN ── */
        .main-content {
            padding: 28px;
        }

        /* ── PAGE HEADER ── */
        .page-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 22px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-title {
            font-size: 20px;
            font-weight: 600;
            color: #1A1A2E;
            margin: 0;
        }
        .page-subtitle {
            font-size: 13px;
            color: #6B7280;
            margin-top: 3px;
        }

        /* ── STAT CARDS ── */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-bottom: 22px;
        }
        .stat-card {
            background: #fff;
            border: 1px solid #E9EDF5;
            border-radius: 14px;
            padding: 18px 20px;
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 10px;
        }
        .stat-info .stat-label {
            font-size: 12px;
            color: #6B7280;
            margin-bottom: 5px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .stat-info .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #1A1A2E;
            line-height: 1;
        }
        .stat-info .stat-pill {
            display: inline-block;
            margin-top: 7px;
            font-size: 11px;
            font-weight: 500;
            padding: 3px 10px;
            border-radius: 20px;
        }
        .stat-icon-wrap {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        .icon-purple { background: #EEEDFE; }
        .icon-green  { background: #EAF3DE; }
        .icon-blue   { background: #E6F1FB; }
        .icon-amber  { background: #FAEEDA; }
        .pill-purple { background: #EEEDFE; color: #3C3489; }
        .pill-green  { background: #EAF3DE; color: #3B6D11; }
        .pill-blue   { background: #E6F1FB; color: #185FA5; }
        .pill-amber  { background: #FAEEDA; color: #854F0B; }

        /* ── TABLE CARD ── */
        .table-card {
            background: #fff;
            border: 1px solid #E9EDF5;
            border-radius: 14px;
            overflow: hidden;
        }
        .table-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 22px;
            border-bottom: 1px solid #F0F2F8;
        }
        .table-card-title {
            font-size: 15px;
            font-weight: 600;
            color: #1A1A2E;
        }
        .table-card-time {
            font-size: 12px;
            color: #9CA3AF;
        }

        /* ── TABLE ── */
        .antrian-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13.5px;
        }
        .antrian-table thead tr {
            background: #F8F9FC;
        }
        .antrian-table th {
            padding: 12px 18px;
            text-align: left;
            font-weight: 600;
            font-size: 11.5px;
            color: #6B7280;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid #F0F2F8;
            white-space: nowrap;
        }
        .antrian-table td {
            padding: 15px 18px;
            border-bottom: 1px solid #F8F9FC;
            color: #374151;
            vertical-align: middle;
        }
        .antrian-table tbody tr:last-child td {
            border-bottom: none;
        }
        .antrian-table tbody tr:hover {
            background: #FAFBFD;
        }

        /* Queue number badge */
        .queue-num {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: #EEEDFE;
            color: #3C3489;
            font-weight: 700;
            font-size: 13px;
        }

        /* Patient name */
        .patient-name {
            font-weight: 600;
            color: #1A1A2E;
        }

        /* Poli badges */
        .poli-badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .poli-umum  { background: #E6F1FB; color: #185FA5; }
        .poli-gigi  { background: #FBEAF0; color: #993556; }
        .poli-anak  { background: #EAF3DE; color: #3B6D11; }

        /* Jenis/status badges */
        .jenis-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 11px;
            border-radius: 20px;
            font-size: 11.5px;
            font-weight: 600;
        }
        .jenis-bpjs { background: #EAF3DE; color: #3B6D11; }
        .jenis-umum { background: #E6F1FB; color: #185FA5; }
        .dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            display: inline-block;
        }
        .dot-green { background: #3B6D11; }
        .dot-blue  { background: #185FA5; }

        /* Biaya */
        .biaya-text {
            font-weight: 600;
            color: #1A1A2E;
        }

        /* Action buttons */
        .action-group {
            display: flex;
            gap: 7px;
        }
        .btn-edit-custom {
            background: #FAEEDA;
            color: #854F0B;
            border: none;
            border-radius: 8px;
            padding: 6px 14px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.15s;
        }
        .btn-edit-custom:hover { background: #FAC775; color: #633806; }

        .btn-done-custom {
            background: #FCEBEB;
            color: #A32D2D;
            border: none;
            border-radius: 8px;
            padding: 6px 14px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.15s;
        }
        .btn-done-custom:hover { background: #F7C1C1; color: #791F1F; }

        /* Add button */
        .btn-add {
            background: #185FA5;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            font-size: 13.5px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 7px;
            transition: background 0.15s;
        }
        .btn-add:hover { background: #0C447C; color: #fff; }

        /* ── MODAL ── */
        .modal-content {
            border-radius: 16px !important;
            border: 1px solid #E9EDF5 !important;
            box-shadow: 0 8px 30px rgba(0,0,0,0.08) !important;
        }
        .modal-header {
            padding: 18px 22px !important;
            border-bottom: 1px solid #F0F2F8 !important;
        }
        .modal-title {
            font-size: 15px !important;
            font-weight: 600 !important;
            color: #1A1A2E !important;
        }
        .modal-body {
            padding: 22px !important;
        }
        .modal-footer {
            padding: 14px 22px !important;
            border-top: 1px solid #F0F2F8 !important;
        }
        .modal-label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            color: #6B7280;
            margin-bottom: 7px;
        }
        .modal-input, .modal-select {
            width: 100%;
            border: 1px solid #E0E4EF;
            border-radius: 9px;
            padding: 9px 14px;
            font-size: 14px;
            color: #1A1A2E;
            background: #fff;
            outline: none;
            transition: border 0.15s;
            -webkit-appearance: none;
            appearance: none;
        }
        .modal-input:focus, .modal-select:focus {
            border-color: #185FA5;
            box-shadow: 0 0 0 3px rgba(24,95,165,0.1);
        }
        .btn-modal-cancel {
            background: #F3F4F6;
            color: #374151;
            border: none;
            border-radius: 9px;
            padding: 9px 18px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-modal-cancel:hover { background: #E5E7EB; }
        .btn-modal-submit {
            background: #185FA5;
            color: #fff;
            border: none;
            border-radius: 9px;
            padding: 9px 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-modal-submit:hover { background: #0C447C; }

        /* ── FOOTER ── */
        .footer {
            text-align: center;
            padding: 20px;
            color: #9CA3AF;
            font-size: 12px;
            margin-top: 8px;
        }

        /* ── RESPONSIVE ── */
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .main-content { padding: 16px; }
            .antrian-table th:nth-child(5),
            .antrian-table td:nth-child(5) { display: none; }
        }
        @media (max-width: 480px) {
            .stats-row { grid-template-columns: 1fr 1fr; }
            .page-header { flex-direction: column; }
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar-custom">
        <div class="navbar-inner">
            <a class="nav-brand" href="#">
                <div class="brand-icon">🏥</div>
                Manajemen Antrian RS
            </a>
            <div class="nav-meta"><?php echo date('l, d F Y'); ?></div>
        </div>
    </nav>

    <div class="main-content">

        <!-- PAGE HEADER -->
        <div class="page-header">
            <div>
                <h1 class="page-title">Daftar Pasien Menunggu</h1>
                <div class="page-subtitle">Kelola antrian dan data pasien hari ini</div>
            </div>
            <button type="button" class="btn-add" data-bs-toggle="modal" data-bs-target="#modalTambah">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                    <path d="M8 2v12M2 8h12" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/>
                </svg>
                Daftar Pasien Baru
            </button>
        </div>

        <!-- STAT CARDS -->
        <?php
            $total = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM antrian"));
            $bpjs  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM antrian WHERE jenis_pasien='BPJS'"));
            $umum  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM antrian WHERE jenis_pasien='Umum'"));
        ?>
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Total Antrian</div>
                    <div class="stat-value"><?php echo $total; ?></div>
                    <span class="stat-pill pill-purple">Hari ini</span>
                </div>
                <div class="stat-icon-wrap icon-purple">🧑‍⚕️</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Pasien BPJS</div>
                    <div class="stat-value"><?php echo $bpjs; ?></div>
                    <span class="stat-pill pill-green">BPJS Gratis</span>
                </div>
                <div class="stat-icon-wrap icon-green">✅</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Pasien Umum</div>
                    <div class="stat-value"><?php echo $umum; ?></div>
                    <span class="stat-pill pill-blue">Bayar penuh</span>
                </div>
                <div class="stat-icon-wrap icon-blue">💳</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Menunggu</div>
                    <div class="stat-value"><?php echo $total; ?></div>
                    <span class="stat-pill pill-amber">Belum selesai</span>
                </div>
                <div class="stat-icon-wrap icon-amber">🕐</div>
            </div>
        </div>

        <!-- TABLE CARD -->
        <div class="table-card">
            <div class="table-card-header">
                <div class="table-card-title">Antrian Aktif</div>
                <div class="table-card-time"><?php echo date('H:i'); ?> WIB</div>
            </div>

            <table class="antrian-table">
                <thead>
                    <tr>
                        <th>Antrian</th>
                        <th>Nama Pasien</th>
                        <th>Poli Tujuan</th>
                        <th>Status Pasien</th>
                        <th>Biaya Periksa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $query = mysqli_query($conn, "SELECT * FROM antrian");
                        while ($row = mysqli_fetch_assoc($query)) {
                            $poliClass = 'poli-umum';
                            if ($row['poli_tujuan'] == 'Poli Gigi') $poliClass = 'poli-gigi';
                            if ($row['poli_tujuan'] == 'Poli Anak') $poliClass = 'poli-anak';
                    ?>
                    <tr>
                        <td><span class="queue-num">#<?php echo $row['id_antrian']; ?></span></td>
                        <td><span class="patient-name"><?php echo htmlspecialchars($row['nama_pasien']); ?></span></td>
                        <td><span class="poli-badge <?php echo $poliClass; ?>"><?php echo $row['poli_tujuan']; ?></span></td>
                        <td>
                            <span class="jenis-badge <?php echo ($row['jenis_pasien'] == 'BPJS') ? 'jenis-bpjs' : 'jenis-umum'; ?>">
                                <span class="dot <?php echo ($row['jenis_pasien'] == 'BPJS') ? 'dot-green' : 'dot-blue'; ?>"></span>
                                <?php echo $row['jenis_pasien']; ?>
                            </span>
                        </td>
                        <td><span class="biaya-text"><?php echo formatRupiah($row['biaya']); ?></span></td>
                        <td>
                            <div class="action-group">
                                <button class="btn-edit-custom"
                                    data-bs-toggle="modal"
                                    data-bs-target="#modalEdit<?php echo $row['id_antrian']; ?>">
                                    Edit
                                </button>
                                <a href="../../php/controller/proses_hapus.php?id=<?php echo $row['id_antrian']; ?>"
                                   class="btn-done-custom"
                                   onclick="return confirm('Tandai pasien ini sudah selesai periksa?');">
                                    Selesai
                                </a>
                            </div>
                        </td>
                    </tr>

                    <!-- Modal Edit -->
                    <div class="modal fade" id="modalEdit<?php echo $row['id_antrian']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Data Pasien #<?php echo $row['id_antrian']; ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form action="../../php/controller/proses_edit.php" method="POST">
                                    <div class="modal-body">
                                        <input type="hidden" name="id_antrian" value="<?php echo $row['id_antrian']; ?>">

                                        <div class="mb-3">
                                            <label class="modal-label">Nama Lengkap</label>
                                            <input type="text" name="nama_pasien" class="modal-input"
                                                value="<?php echo htmlspecialchars($row['nama_pasien']); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="modal-label">Poli Tujuan</label>
                                            <select name="poli_tujuan" class="modal-select" required>
                                                <option value="Poli Umum" <?php if($row['poli_tujuan']=='Poli Umum') echo 'selected'; ?>>Poli Umum</option>
                                                <option value="Poli Gigi" <?php if($row['poli_tujuan']=='Poli Gigi') echo 'selected'; ?>>Poli Gigi</option>
                                                <option value="Poli Anak" <?php if($row['poli_tujuan']=='Poli Anak') echo 'selected'; ?>>Poli Anak</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="modal-label">Status Pasien</label>
                                            <select name="jenis_pasien" class="modal-select" required>
                                                <option value="Umum" <?php if($row['jenis_pasien']=='Umum') echo 'selected'; ?>>Umum (Bayar Penuh)</option>
                                                <option value="BPJS" <?php if($row['jenis_pasien']=='BPJS') echo 'selected'; ?>>BPJS (Gratis)</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn-modal-cancel" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn-modal-submit">Simpan Perubahan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="footer">Sistem Manajemen Antrian RS &mdash; <?php echo date('Y'); ?></div>
    </div>

    <!-- Modal Tambah Pasien -->
    <div class="modal fade" id="modalTambah" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Form Pendaftaran Pasien</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="../../php/controller/proses_tambah.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="modal-label">Nama Lengkap</label>
                            <input type="text" name="nama_pasien" class="modal-input"
                                placeholder="Masukkan nama pasien..." required>
                        </div>
                        <div class="mb-3">
                            <label class="modal-label">Poli Tujuan</label>
                            <select name="poli_tujuan" class="modal-select" required>
                                <option value="Poli Umum">Poli Umum</option>
                                <option value="Poli Gigi">Poli Gigi</option>
                                <option value="Poli Anak">Poli Anak</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="modal-label">Status Pasien</label>
                            <select name="jenis_pasien" class="modal-select" required>
                                <option value="Umum">Umum (Bayar Penuh)</option>
                                <option value="BPJS">BPJS (Gratis)</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-modal-cancel" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn-modal-submit" style="width:100%;justify-content:center;">
                            Simpan ke Antrian
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
