<?php
namespace AntrianRS;

// Interface untuk standardisasi
interface KalkulasiBiaya {
    public function hitungBiaya();
}

// Class Induk
class PasienUtama {
    protected $biaya_dasar;

    public function __construct($biaya = 150000) {
        $this->biaya_dasar = $biaya; // Biaya periksa dokter standar
    }
}

// Class Anak 1 (Pasien Umum bayar penuh)
class PasienUmum extends PasienUtama implements KalkulasiBiaya {
    public function hitungBiaya() {
        return $this->biaya_dasar; 
    }
}

// Class Anak 2 (Pasien BPJS gratis)
class PasienBPJS extends PasienUtama implements KalkulasiBiaya {
    public function hitungBiaya() {
        return 0; // Disubsidi pemerintah
    }
}
?>